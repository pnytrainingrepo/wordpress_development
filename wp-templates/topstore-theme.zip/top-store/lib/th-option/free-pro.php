  <div class="th-dashboard">
      <div class="content free-pro">
            <table class="table">
               <tbody class="table-body">
                  <tr class="table-head">
                     <th class="title" align="left"><?php _e('Features','top-store'); ?></th>
                     <th class="status" align="center"><?php _e('Top Store','top-store'); ?> </th>
                     <th class="status" align="center"><?php _e('Top Store Pro','top-store'); ?> </th>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Section Hide Option','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Header Layout','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(One layout)','top-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Multiple Possibilities)','top-store'); ?> </span></td>
                  </tr>


                  



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Footer Layout','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Full Color & Background Control','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Basic)','top-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Advanced)','top-store'); ?> </span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Top Slider Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(One Layouts)','top-store'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Four Layouts)','top-store'); ?> </span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Ribbon Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Tabbed Product Carousel Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Woo Category Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(One Layouts)','top-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Three Layouts)','top-store'); ?> </span></td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product List Carousel Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Banner Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Two Layouts)','top-store'); ?> </span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Five Layouts)','top-store'); ?> </span>
                     </td>

                  </tr>





                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Support','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Basic)','top-store'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     <span class="info"><?php _e('(Priority)','top-store'); ?> </span></td>

                  </tr>








                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Section Ordering','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Off Canvas Sidebar','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Five Custom section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Big Featured Product Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Highlight Section','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Product List Slider Widget','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Product Slider Widget','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Single Category Slider Widget','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Single Product Slider Widget','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>
                  
                    <tr class="feature-row th-buy-pro">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pro Theme','top-store'); ?> </h4>
                        </div>
                     </td>
                     <td class="status upsell"><?php _e('Access to all Pro features','top-store'); ?> </td>
                     <td class="status success"><a href="https://themehunk.com/product/top-store-pro/" target="_blank" rel="external noreferrer noopener" class="components-button is-primary"><?php _e('Get Top Store Pro Now','top-store'); ?></a></td>
                  </tr>



               </tbody>
            </table>
      </div>
   </div>
